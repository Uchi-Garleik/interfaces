<?php
    class Modelo{
        function __construct(){
        }
    }
?>